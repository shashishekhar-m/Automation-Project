﻿internal class txtUserID
{
    public static string Text { get; internal set; }
}